#include <mrk/fs.h>
#include <mrk/alloc.h>
#include <mrk/lock.h>
#include <mrk/log.h>

static mutex ops_lock;

fs::handle* fs::open(char* path, fs::open_mode mode)
{
    ops_lock.lock();

    // find the node
    fs::tnode* req = fs::path_to_node(path, NODE_NO_CREATE, (fs::node_type)0);
    if (!req) {
	ops_lock.unlock();
	return nullptr;
    }
    req->inode->refcount++;

    fs::handle* nd = (fs::handle*)mm::alloc(sizeof(fs::handle));
    nd->tnode = req;
    nd->inode = req->inode;
    nd->seek_pos = 0;
    nd->mode = mode;

    // return the handle
    ops_lock.unlock();
    return nd;
}

int64_t fs::close(fs::handle* handle)
{
    ops_lock.lock();

    handle->inode->refcount--;
    mm::free(handle);

    ops_lock.unlock();
    return 0;
}

int64_t fs::read(fs::handle* handle, size_t len, void* buff)
{
    ops_lock.lock();
    fs::inode* inode = handle->inode;

    if (handle->seek_pos + len > inode->size) {
        len = inode->size - handle->seek_pos;
        if (len == 0) {
            ops_lock.unlock();
	    return len;
	}
    }

    int64_t status = handle->inode->fs->read(handle->inode, handle->seek_pos, len, buff);
    if (status == -1)
        len = 0;

    ops_lock.unlock();
    return (int64_t)len;
}

int64_t fs::write(fs::handle* handle, size_t len, const void* buff)
{
    // Don't write to read-only files
    if (handle->mode == open_mode::read) {
        log("fs: file is read only\n");
        return 0;
    }

    ops_lock.lock();
    fs::inode* inode = handle->inode;

    // expand file if writing more data than its size
    if (handle->seek_pos + len > inode->size) {
        inode->size = handle->seek_pos + len;
        inode->fs->sync(inode);
    }

    int64_t status = inode->fs->write(inode, handle->seek_pos, len, buff);
    if (status == -1)
        len = 0;

    ops_lock.unlock();
    return (int64_t)len;
}

int64_t fs::seek(fs::handle* handle, size_t pos)
{
    // seek position is out of bounds and mode is read only
    if (pos >= handle->inode->size && handle->mode == open_mode::read) {
        log("fs: seek pos is out of bounds\n");
        return -1;
    }

    handle->seek_pos = pos;
    return 0;
}

int64_t fs::create(char* path, fs::node_type type)
{
    int64_t status = 0;
    ops_lock.lock();

    fs::tnode* node = fs::path_to_node(path, NODE_CREATE | NODE_ERR_ON_EXIST, type);
    if (!node)
        status = -1;

    ops_lock.unlock();
    return status;
}

int64_t fs::chmod(fs::handle* handle, int32_t newperms)
{
    // Read-Only files can't have their permissions changed
    if (handle->mode == open_mode::read) {
        log("fs: %s is opened as read-only\n", handle->tnode->name);
        return -1;
    }

    // set new permissions and sync
    handle->inode->perms = newperms;
    handle->inode->fs->sync(handle->inode);
    return 0;
}

int64_t fs::mount(char* device, char* path, char* fsname)
{
    ops_lock.lock();

    // get the fs info
    fs::filesystem* fs = fs::get_fs(fsname);
    if (!fs) {
	ops_lock.unlock();
        return -1;
    }

    // get the block device if needed
    fs::tnode* dev = nullptr;
    if (!fs->no_backing) {
        dev = fs::path_to_node(device, NODE_NO_CREATE, (fs::node_type)0);
        if (!dev) {
            ops_lock.unlock();
	    return -1;
	}
        if (dev->inode->type != fs::node_type::blockdev) {
            log("fs: %s is not a block device\n", device);
            ops_lock.unlock();
	    return -1;
        }
    }
    log("hey!\n");

    fs::tnode* at = fs::path_to_node(path, NODE_NO_CREATE, (fs::node_type)0);
    if (!at) {
        ops_lock.unlock();
	return -1;
    }
    if (at->inode->type != fs::node_type::directory || at->inode->child.size() != 0) {
        log("fs: '%s' is not an empty folder\n", path);
        ops_lock.unlock();
	return -1;
    }

    mm::free(at->inode);

    // mount the fs
    at->inode = fs->mount(dev ? dev->inode : NULL);
    at->inode->mountpoint = at;

    log("fs: mounted %s at %s as %s\n", device ? device : "<no-dev>", path, fsname);
    ops_lock.unlock();
    return 0;
}

